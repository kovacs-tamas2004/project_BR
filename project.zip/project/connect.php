<?php
    $server = "localhost";
    $db = "project";
    $user = "root";
    $pwd = "";
    $port = 3306;

    try{
        $connect = new PDO("mysql:host=$server; port=$port; dbname=$db", $user, $pwd);
    }
    catch(PDOException $ex){
        print $ex -> getMessage();
    }
?>