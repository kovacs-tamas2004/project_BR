$(document).ready(function() {

    $('#reservationForm').submit(function(event) {
        event.preventDefault(); 

      
        var formData = $(this).serialize();

   
        $.ajax({
            type: 'POST',
            url: 'saveReservation.php',
            data: formData,
            success: function(response) {
                if (response == 'success') {
                    alert('A foglalás sikeresen mentve!');
  
                    $('#reservationForm')[0].reset();
                } else {
                    alert('Hiba történt a foglalás mentése közben!');
                }
            },
            error: function() {
                alert('Hiba történt a foglalás mentése közben!');
            }
        });
    });


    function listReservations() {
        $.ajax({
            type: 'GET',
            url: 'getAllReservations.php',
            success: function(reservations) {
                var reservationList = $('#reservationList');

                reservationList.empty(); 

                reservations.forEach(function(reservation) {
                    var reservationItem = `
                        <div class="reservation-item">
                            <p><strong>Jármű rendszám:</strong> ${reservation.vehicle_type}</p>
                            <p><strong>Név:</strong> ${reservation.customer_name}</p>
                            <p><strong>E-mail:</strong> ${reservation.email}</p>
                            <p><strong>Foglalás dátuma:</strong> ${reservation.reservation_date}</p>
                        </div>
                    `;

                    reservationList.append(reservationItem);
                });
            },
            error: function() {
                alert('Hiba történt a foglalások lekérése közben!');
            }
        });
    }


    listReservations();
});
