<?php
require_once 'connect.php';
require_once 'functions.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['vehicle_type'], $_POST['customer_name'], $_POST['email'], $_POST['reservation_date'])) {
        $formData = [
            'vehicle_type' => $_POST['vehicle_type'],
            'customer_name' => $_POST['customer_name'],
            'email' => $_POST['email'],
            'reservation_date' => $_POST['reservation_date']
        ];

        $success = saveReservation($formData, $connect);
        if ($success) {
            echo "Foglalás sikeresen mentve!";
        } else {
            echo "Hiba történt a foglalás mentése közben.";
        }
    } else {
        echo "Hiányzó adatok a foglalás mentéséhez.";
    }
} else {
    echo "Hiba!";
}
?>
