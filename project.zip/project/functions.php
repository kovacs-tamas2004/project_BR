<?php
function saveReservation($formData, $connect) {
    $vehicleType = $formData['vehicle_type'];
    $customerName = $formData['customer_name'];
    $email = $formData['email'];
    $reservationDate = $formData['reservation_date'];

    try {
        $stmt = $connect->prepare("INSERT INTO reservations (vehicle_type, customer_name, email, reservation_date) VALUES (?, ?, ?, ?)");
        $stmt->execute([$vehicleType, $customerName, $email, $reservationDate]);

        return true;
    } catch (PDOException $ex) {
        error_log('Hiba történt a foglalás mentése közben: ' . $ex->getMessage());
        return false;
    }
}

function getAllReservations($connect) {
    try {
        $stmt = $connect->query("SELECT * FROM reservations ORDER BY id DESC");
        $reservations = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $reservations;
    } catch (PDOException $ex) {
        error_log('Hiba történt a foglalások lekérése közben: ' . $ex->getMessage());
        return [];
    }
}

?>
