<?php

require_once('connect.php');

try {
    
    $stmt = $connect->query("SELECT * FROM reservations ORDER BY id DESC");
    $reservations = $stmt->fetchAll(PDO::FETCH_ASSOC);

    header('Content-Type: application/json');
    echo json_encode($reservations);
} catch (PDOException $ex) {
   
    echo json_encode([]);
}
?>
