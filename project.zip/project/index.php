<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Jármű bejelentése műszaki vizsgára</title>
</head>
<body>

    <div class="container">

        <h2>Foglalási űrlap</h2>
        <form id="reservationForm">
            <label for="vehicle_type">Jármű rendszám:</label>
            <input type="text" id="vehicle_type" name="vehicle_type" required><br><br>

            <label for="customer_name">Név:</label>
            <input type="text" id="customer_name" name="customer_name" required><br><br>

            <label for="email">E-mail cím:</label>
            <input type="email" id="email" name="email" required><br><br>

            <label for="reservation_date">Foglalás dátuma:</label>
            <input type="datetime-local" id="reservation_date" name="reservation_date" required><br><br>

            <button type="submit">Foglalás mentése</button>
        </form>

        <h2>Foglalások listája</h2>
        <div id="reservationList">
        </div>

    </div>

    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="script.js"></script>
</body>
</html>
